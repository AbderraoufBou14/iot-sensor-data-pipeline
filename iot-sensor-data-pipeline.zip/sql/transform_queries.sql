-- Exemple d'agrégation par heure
SELECT date_trunc('hour', timestamp) AS hour,
       AVG(temperature) AS avg_temp,
       AVG(humidity) AS avg_humidity,
       AVG(pressure) AS avg_pressure
FROM sensor_data
GROUP BY hour
ORDER BY hour;
