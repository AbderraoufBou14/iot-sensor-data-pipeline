import csv
import random
import time
from datetime import datetime

file_path = 'data/generated_data.csv'

with open(file_path, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['timestamp', 'temperature', 'humidity', 'pressure'])
    while True:
        timestamp = datetime.utcnow().isoformat()
        temp = round(random.uniform(18.0, 30.0), 2)
        humidity = round(random.uniform(30.0, 70.0), 2)
        pressure = round(random.uniform(990.0, 1020.0), 2)
        writer.writerow([timestamp, temp, humidity, pressure])
        print(f"Written: {timestamp}, {temp}, {humidity}, {pressure}")
        time.sleep(1)
