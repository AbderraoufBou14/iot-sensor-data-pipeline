import csv
import psycopg2

conn = psycopg2.connect(
    dbname="sensordb",
    user="admin",
    password="adminpass",
    host="localhost",
    port="5432"
)
cursor = conn.cursor()

with open('data/generated_data.csv', 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        cursor.execute(
            """
            INSERT INTO sensor_data (timestamp, temperature, humidity, pressure)
            VALUES (%s, %s, %s, %s)
            """,
            (row['timestamp'], row['temperature'], row['humidity'], row['pressure'])
        )
conn.commit()
cursor.close()
conn.close()
